HERSTYLE: chic wigs website
===========================

FILES
  index.html            the page structure (header, hero, store, footer)
  css/styles.css        all the design: colours, layout, animations
  js/app.js             the website: store, cart, login, admin, revenue charts
  js/local-backend.js   saves products, orders and accounts inside your browser
  assets/logo.svg       the Herstyle logo
Keep these files together in the same folders. They load each other by relative path.

HOW TO RUN
1. Unzip the folder.
2. Double-click index.html (best in Chrome, Edge or Firefox).
   If a browser blocks it, open a terminal in this folder and run:
       python3 -m http.server 8000
   then visit http://localhost:8000

FIRST-TIME SETUP
- Click "Login", enter your name and email. The FIRST account created on a computer
  becomes the SUPER ADMIN. Use your own details first.
- You then land in the admin dashboard: add products, manage orders, see revenue.
- To try the customer side, use "Log out" in the dashboard and log in with another email.
- Admins: Team tab, add an admin's email and choose what they can access.
  They use "Admin login" (footer) and enter that email.

FONTS
The Playfair Display and Jost fonts load from Google Fonts, so the exact look needs an
internet connection. Offline, the site falls back to Georgia and system fonts.

IMPORTANT
- Data (products, photos, orders, accounts) is saved in the browser you use, not shared
  between computers. To move it: Dashboard > Settings > Export, then Import on the other computer.
- Four sample wigs show until you add your first product.
- Logins here are for demonstration. A live public store needs a real backend
  (database, secure logins, image storage, payments).
