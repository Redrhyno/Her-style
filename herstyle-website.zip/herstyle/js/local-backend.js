/* Herstyle local backend: stores products, orders and accounts in this browser (IndexedDB). */
/* ---------- local mode (zip version): browser-based stand-in for the hosted backend ---------- */
if(!window.claude){window.HS_LOCAL=1;(()=>{
  const open=new Promise(r=>{const q=indexedDB.open('herstyle',1);q.onupgradeneeded=()=>q.result.createObjectStore('d');q.onsuccess=()=>r(q.result)});
  const run=async(m,f)=>{const d=await open;return new Promise((res,rej)=>{const t=d.transaction('d',m),r=f(t.objectStore('d'));t.oncomplete=()=>res(r.result);t.onerror=()=>rej(t.error)})};
  const all=async()=>{const d=await open;return new Promise(r=>{const o={},q=d.transaction('d').objectStore('d').openCursor();q.onsuccess=()=>{const c=q.result;if(c){o[c.key]=c.value;c.continue()}else r(o)}})};
  const subs=[],ping=()=>subs.forEach(f=>f()),snap=(p,v)=>({id:p.split('/').pop(),exists:v!==undefined,data:()=>v});
  const col=(c,ord)=>({orderBy:(f,d)=>col(c,[f,d]),
    onSnapshot(cb){const f=async()=>{const o=await all();const docs=Object.keys(o).filter(k=>k.startsWith(c+'/')&&!k.slice(c.length+1).includes('/')).map(k=>({id:k.slice(c.length+1),data:()=>o[k]}));if(ord)docs.sort((a,b)=>(a.data()[ord[0]]>b.data()[ord[0]]?1:-1)*(ord[1]==='asc'?1:-1));cb({docs})};subs.push(f);f();return()=>{}},
    async add(v){const id=Date.now().toString(36)+Math.random().toString(36).slice(2,6);await run('readwrite',s=>s.put(v,c+'/'+id));ping();return{id}}});
  const docr=p=>({async get(){return snap(p,await run('readonly',s=>s.get(p)))},async set(v){await run('readwrite',s=>s.put(v,p));ping()},
    async update(v){const o=(await run('readonly',s=>s.get(p)))||{};await run('readwrite',s=>s.put({...o,...v},p));ping()},async delete(){await run('readwrite',s=>s.delete(p));ping()},
    onSnapshot(cb){const f=async()=>cb(snap(p,await run('readonly',s=>s.get(p))));subs.push(f);f();return()=>{}}});
  const db={collection:col,doc:docr},assets={upload:f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res({url:r.result});r.onerror=rej;r.readAsDataURL(f)}),delete:async()=>{}};
  const ls={get:k=>{try{return JSON.parse(localStorage.getItem('hs:'+k))}catch(e){return null}},set:(k,v)=>localStorage.setItem('hs:'+k,JSON.stringify(v))};
  const user={me:async()=>{const m=ls.get('me');return m?{...m,isOwner:ls.get('owner')===m.id}:{id:null,name:'',email:'',isOwner:false}},
    signIn:(name,email)=>{const id=key(email);ls.set('me',{id,name,email});if(!ls.get('owner'))ls.set('owner',id)},signOut:()=>localStorage.removeItem('hs:me'),
    dump:all,load:async o=>{for(const k in o)await run('readwrite',s=>s.put(o[k],k));ping()}};
  window.claude={use:async n=>({db,assets,user})[n]};
})()}
