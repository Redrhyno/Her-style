/* Herstyle app: storefront, cart and checkout, login, admin dashboard, revenue charts. */

const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LINK='https://claude.ai/artifact/5u8oJACb1W3g7PVdt1EK5e',MO=['January','February','March','April','May','June','July','August','September','October','November','December'];
let db,assets,user,io,view='store',arg='',tab='',done=null,me={id:null,name:'',email:'',isOwner:false},products=[],orders=[],admins=[],settings={},filter='All',cart=[];
try{cart=JSON.parse(localStorage.getItem('hs_cart')||'[]')}catch(e){}
const saveCart=()=>{try{localStorage.setItem('hs_cart',JSON.stringify(cart))}catch(e){}$('#cc').textContent=cart.reduce((a,c)=>a+c.q,0)};
const wigSvg='<svg viewBox="0 0 64 64" fill="#fff"><path d="M32 6C18 6 10 18 12 34c1 9-2 16-6 22 8 1 14-2 17-7-2-8 0-17 9-21 9 4 11 13 9 21 3 5 9 8 17 7-4-6-7-13-6-22C54 18 46 6 32 6z"/></svg>';
const num=p=>+String(p.price||'').replace(/[^\d.]/g,'')||0,sym=p=>(String(p.price||'').match(/^[^\d]*/)||[''])[0].trim()||'₦';
const cover=p=>(p.images&&p.images[0])||'',wa=()=>(settings.whatsapp||'').replace(/\D/g,''),key=e=>e.toLowerCase().replace(/[^a-z0-9]/g,'_');
const say=(sel,t)=>{const s=$(sel);if(s)s.innerHTML=t?`<div class="msg">${t}</div>`:''},find=id=>[...products,...DEMO].find(x=>x.id===id);
const myAdmin=()=>admins.find(a=>a.uid&&a.uid===me.id),role=()=>me.isOwner?'super':myAdmin()?'admin':null;
const can=k=>role()==='super'||!!(myAdmin()?.perms?.[k]);
const addCart=(id,q)=>{const x=cart.find(i=>i.id===id);x?x.q+=q:cart.push({id,q});saveCart()};
function reveal(){io=io||new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.08});$$('.rv:not(.in)').forEach(el=>io.observe(el))}

/* ---------- navigation (no hash dependence) ---------- */
function nav(v,a='',sec){view=v;arg=a;if(v!=='cart')done=null;
  const m={store:'store',cart:'vCart',login:'vLogin',admin:'vAdmin'}[v];
  $$('main.view').forEach(x=>x.classList.toggle('hide',x.id!==m));
  if(v==='cart')buildCart();if(v==='login')buildLogin();if(v==='admin')buildAdmin();
  sec?setTimeout(()=>document.getElementById(sec)?.scrollIntoView({behavior:'smooth'}),40):scrollTo(0,0)}
document.addEventListener('click',e=>{if(e.target.id==='lb')return lbClose();const a=e.target.closest('[data-nav],[data-add],[data-tg],[data-sl],[data-lb],[data-lbx],[data-lbn],[data-out]');if(!a)return;e.preventDefault();const d=a.dataset;
  if(d.add){addCart(d.add,1);a.textContent='Added ✓';setTimeout(()=>a.textContent='Add to cart',1300)}
  else if(d.tg!==undefined){const c=a.closest('.card');c.classList.toggle('open');openIds[c.classList.contains('open')?'add':'delete'](c.dataset.id)}
  else if(d.sl){const t=a.closest('.car').querySelector('.trk'),n=t.children.length,i=Math.round(t.scrollLeft/t.clientWidth)+ +d.sl;t.scrollTo({left:((i+n)%n)*t.clientWidth,behavior:'smooth'})}
  else if(d.lb!==undefined)lbOpen(a.closest('.card').dataset.id,+d.lb);
  else if(d.lbx!==undefined)lbClose();
  else if(d.lbn)lbShow(lb.i+ +d.lbn);
  else if(d.out!==undefined){user.signOut();me={id:null,name:'',email:'',isOwner:false};nav('login')}
  else nav(d.nav,'',d.sec)});

/* ---------- store ---------- */
const grad=(a,b,t,k)=>'data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 500"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="400" height="500" fill="url(#g)"/><g transform="${k==1?'translate(400 0) scale(-1 1)':k==2?'translate(40 40) scale(.9)':''}"><path d="M200 90c-70 0-110 60-100 140 6 50-8 90-30 120 40 6 70-10 85-35-10-45 0-95 45-110 45 15 55 65 45 110 15 25 45 41 85 35-22-30-36-70-30-120 10-80-30-140-100-140z" fill="#fff" fill-opacity=".85"/></g><text x="200" y="460" text-anchor="middle" font-family="Georgia,serif" font-size="24" fill="#fff">${t}</text></svg>`);
const DEMO=[['Sleek Lace Front','₦85,000','Lace Front','#ff6f9c','#c8102e'],['Bouncy Curls','₦72,000','Curly','#ffb3c8','#e8466f'],['Glam Bob','₦58,000','Bob','#e8466f','#8f0a22'],['Silky Straight','₦95,000','Straight','#f7869f','#b5213b']].map((x,i)=>({id:'demo'+i,demo:1,name:x[0],price:x[1],category:x[2],images:['Front','Side','Back'].map((t,k)=>grad(x[3],x[4],t,k)),description:'A soft, natural-looking wig that moves with you. Breathable cap, easy to style and made to last.\n\nThis is a sample listing. Add your own styles from the admin dashboard and these will disappear.',length:'18 inches',colour:'Rose red',texture:'Silky',cap:'Medium, adjustable'}));
const lb={list:[],i:0};
function lbShow(i){const n=lb.list.length;lb.i=(i+n)%n;const im=$('#lbi');im.style.animation='none';void im.offsetWidth;im.style.animation='';im.src=lb.list[lb.i];$('#lbc').textContent=n>1?`${lb.i+1} / ${n}`:'';$$('.ln').forEach(b=>b.classList.toggle('hide',n<2))}
function lbOpen(id,i){const p=find(id);if(!p||!(p.images||[]).length)return;lb.list=p.images;lbShow(i);$('#lb').classList.remove('hide');document.body.style.overflow='hidden'}
const lbClose=()=>{$('#lb').classList.add('hide');document.body.style.overflow=''};
document.addEventListener('keydown',e=>{if($('#lb').classList.contains('hide'))return;if(e.key==='Escape')lbClose();if(e.key==='ArrowRight')lbShow(lb.i+1);if(e.key==='ArrowLeft')lbShow(lb.i-1)});
let tx0=null;$('#lb').addEventListener('touchstart',e=>tx0=e.touches[0].clientX,{passive:true});$('#lb').addEventListener('touchend',e=>{if(tx0===null)return;const dx=e.changedTouches[0].clientX-tx0;tx0=null;if(Math.abs(dx)>50)lbShow(lb.i+(dx<0?1:-1))});
const openIds=new Set();let lastSig='';
function card(p,i){
  const im=p.images||[],n=im.length+(p.video?1:0),id=esc(p.id);
  const sp=[['Length',p.length],['Colour',p.colour],['Texture',p.texture],['Cap size',p.cap]].filter(x=>x[1]).map(x=>`<span>${x[0]}</span><b>${esc(x[1])}</b>`).join('');
  return `<div class="card rv${openIds.has(p.id)?' open':''}" data-id="${id}" style="transition-delay:${i%4*90}ms">${p.soldOut?'<span class="tag">Sold out</span>':p.demo?'<span class="tag" style="background:#7d5a64">Sample</span>':p.badge?`<span class="tag">${esc(p.badge)}</span>`:''}
  <div class="car"><div class="trk">${im.map((u,k)=>`<img src="${esc(u)}" alt="${esc(p.name)} view ${k+1}" data-lb="${k}">`).join('')+(p.video?`<video src="${esc(p.video)}" controls playsinline preload="metadata"></video>`:'')||`<div class="ph" style="aspect-ratio:4/5">${wigSvg}</div>`}</div>
  ${n>1?`<button class="ar l" data-sl="-1" aria-label="Previous">‹</button><button class="ar r" data-sl="1" aria-label="Next">›</button><div class="dots">${Array.from({length:n},(_,k)=>`<b${k?'':' class="on"'}></b>`).join('')}</div>`:''}</div>
  <div class="info"><small>${esc(p.category||'Wig')}</small><h3>${esc(p.name)}</h3><div class="price">${p.was?`<s style="color:var(--mute);font-size:12px;margin-right:6px">${esc(p.was)}</s>`:''}${esc(p.price)}</div>
  <div class="row2">${p.soldOut?'<button class="btn" disabled style="opacity:.5">Sold out</button>':`<button class="btn pulse" data-add="${id}">Add to cart</button>`}<button class="tg" data-tg aria-label="Show all details">⌄</button></div>
  <div class="more"><div><p>${esc(p.description||'A beautiful Herstyle wig, made to make you feel unstoppable.')}</p>${sp?`<div class="spec">${sp}</div>`:''}</div></div></div></div>`}
function renderStore(){
  const shown=products.length?products:DEMO,cats=['All',...new Set(shown.map(p=>p.category).filter(Boolean))];if(!cats.includes(filter))filter='All';
  const l=shown.filter(p=>filter==='All'||p.category===filter),sig=JSON.stringify([filter,cats,l.map(p=>[p.id,p.name,p.price,p.category,p.soldOut,p.description,p.length,p.colour,p.texture,p.cap,p.images,p.video,p.was,p.badge])]);
  if(sig!==lastSig){lastSig=sig;$('#chips').innerHTML=cats.length>2?cats.map(c=>`<button class="chip ${c===filter?'on':''}" data-c="${esc(c)}">${esc(c)}</button>`).join(''):'';$('#grid').innerHTML=l.map(card).join('');reveal()}
  const w=wa();$('#contactLine').innerHTML=w?`<a href="https://wa.me/${w}" target="_blank" rel="noopener" style="text-decoration:underline">Questions? Chat with us on WhatsApp</a>`:'Questions? Get in touch with us.'}
$('#chips').onclick=e=>{if(e.target.dataset.c){filter=e.target.dataset.c;renderStore()}};
document.addEventListener('scroll',e=>{const t=e.target;if(t.classList&&t.classList.contains('trk')){const i=Math.round(t.scrollLeft/t.clientWidth);t.parentNode.querySelectorAll('.dots b').forEach((d,k)=>d.classList.toggle('on',k===i))}},true);

/* ---------- cart & checkout ---------- */
function buildCart(){
  const b=$('#cBody');
  if(done){b.innerHTML=`<div class="panel auth"><h2>Thank you, ${esc(done.name)}!</h2><p>Your order <b>#${esc(done.id.slice(0,6).toUpperCase())}</b> has been received. We’ll call <b>${esc(done.phone)}</b> shortly to confirm delivery.</p><a class="btn" href="#" data-nav="store" data-sec="shop">Keep shopping</a></div>`;return}
  b.innerHTML=`<div class="title" style="padding-top:30px"><h2>Your cart</h2></div><div class="panel" id="cItems"></div><div class="panel" id="cForm"><h3>Delivery details</h3>
  <div class="row"><div><label>Full name</label><input id="f_name" autocomplete="name" value="${esc(me.name)}"></div><div><label>Phone number</label><input id="f_phone" type="tel" autocomplete="tel"></div></div>
  <label>Email (optional)</label><input id="f_email" type="email"><label>Delivery address</label><textarea id="f_addr" rows="2"></textarea>
  <div class="row"><div><label>Payment</label><select id="f_pay"><option>Pay on delivery</option><option>Bank transfer</option></select></div><div><label>Note (colour, cap size…)</label><input id="f_note"></div></div>
  <p style="margin:18px 0 0"><button class="btn" id="place">Place order</button></p><div id="cmsg"></div></div>`;
  $('#place').onclick=placeOrder;drawCart()}
const lines=()=>cart.map(c=>({c,p:find(c.id)})).filter(x=>x.p);
function drawCart(){
  const el=$('#cItems');if(!el||done)return;const L=lines(),t=L.reduce((a,{c,p})=>a+num(p)*c.q,0);
  el.innerHTML=L.length?L.map(({c,p})=>`<div class="li">${cover(p)?`<img src="${esc(cover(p))}" alt="">`:'<span class="z"></span>'}<div><b>${esc(p.name)}</b><small>${esc(p.price)}</small></div><div class="qty"><button data-m="${esc(p.id)}">−</button><span>${c.q}</span><button data-a="${esc(p.id)}">+</button></div><button class="btn ghost sm" data-r="${esc(p.id)}">✕</button></div>`).join('')+`<div class="li" style="justify-content:space-between"><b>Total</b><b class="price" style="font-size:20px;flex:none">${sym(L[0].p)}${t.toLocaleString()}</b></div>`:'<p style="color:var(--mute);text-align:center">Your cart is empty. <a href="#" data-nav="store" data-sec="shop" style="color:var(--red)">Browse the collection</a></p>';
  $('#cForm').classList.toggle('hide',!L.length)}
$('#cBody').onclick=e=>{const d=e.target.dataset,x=cart.find(i=>i.id===(d.m||d.a||d.r));if(!x)return;if(d.a)x.q++;if(d.m)x.q=Math.max(1,x.q-1);if(d.r)cart=cart.filter(i=>i!==x);saveCart();drawCart()};
async function placeOrder(){
  const v=k=>$('#f_'+k).value.trim(),L=lines();
  if(!v('name')||!v('phone')||!v('addr'))return say('#cmsg','Please add your name, phone number and delivery address.');
  if(!me.id)return say('#cmsg','Please <a href="#" data-nav="login" style="text-decoration:underline">log in</a> first. Your cart will be waiting.');
  const total=L.reduce((a,{c,p})=>a+num(p)*c.q,0),o={id:Date.now().toString(36),items:L.map(({c,p})=>({id:p.id,name:p.name,cat:p.category||'',price:p.price,qty:c.q})),total,currency:sym(L[0].p),name:v('name'),phone:v('phone'),email:v('email'),address:v('addr'),note:v('note'),pay:v('pay'),status:'new',createdAt:Date.now()};
  $('#place').disabled=true;say('#cmsg','Sending your order…');
  try{if(!db)throw 0;const ref=db.doc('orders/'+me.id),l=((await ref.get()).data()||{}).list||[];l.push(o);await ref.set({list:l});cart=[];saveCart();done={id:o.id,name:o.name,phone:o.phone};buildCart()}
  catch(e){const txt=encodeURIComponent(`New order from ${o.name} (${o.phone}): `+o.items.map(i=>i.qty+'× '+i.name).join(', ')+`. Total ${o.currency}${total.toLocaleString()}. Address: ${o.address}`);
    say('#cmsg',`We couldn’t submit your order online right now. Please try again${wa()?`, or <a style="text-decoration:underline" target="_blank" rel="noopener" href="https://wa.me/${wa()}?text=${txt}">send it to us on WhatsApp</a>`:''}.`);$('#place').disabled=false}}

/* ---------- login (customers) ---------- */
async function refreshMe(){try{if(user){me={email:'',...(await user.me())}}}catch(e){}
  if(view==='login')buildLogin();if(view==='admin')buildAdmin()}
async function buildLogin(){
  const b=$('#lBody');
  if(!me.id){b.innerHTML=`<div class="panel auth"><h2>Welcome to Herstyle</h2><p style="color:var(--mute)">Log in to place orders and keep track of them in your account.</p>${window.HS_LOCAL?lform():''}<button class="btn" id="lg">Log in</button><div id="lm"></div><p class="sm">Part of the team? <a href="#" data-nav="admin" style="color:var(--red)">Admin login</a></p></div>`;
    $('#lg').onclick=()=>doLogin('#lm');return}
  if(role()){nav('admin');return}
  b.innerHTML=`<div class="panel"><div class="eyebrow">My account</div><h2>Hi, ${esc(me.name||'there')}</h2>${window.HS_LOCAL?'<a href="#" data-out class="sm" style="color:var(--red)">Log out</a>':''}<h3>My orders</h3><div id="mo">Loading…</div></div>`;
  try{const l=((await db.doc('orders/'+me.id).get()).data()||{}).list||[];$('#mo').innerHTML=l.slice().reverse().map(o=>`<div class="li"><div style="white-space:normal"><b style="white-space:normal">#${esc(o.id.slice(0,6).toUpperCase())} · ${esc(o.currency)}${(o.total||0).toLocaleString()}</b><small>${new Date(o.createdAt).toLocaleDateString()} · ${(o.items||[]).map(i=>i.qty+'× '+esc(i.name)).join(', ')} · ${esc(o.status)}</small></div></div>`).join('')||'<p class="sm">No orders yet.</p>'}catch(e){$('#mo').innerHTML='<p class="sm">No orders to show yet.</p>'}}

async function claim(){const em=$('#ae').value.trim().toLowerCase(),a=admins.find(x=>x.email===em);
  if(!a)return say('#am','This email hasn’t been set up as an admin. Check the spelling or ask the super admin.');
  if(a.uid&&a.uid!==me.id)return say('#am','This admin email is already linked to another account. Ask the super admin to reset it.');
  try{const{id,...r}=a;await db.doc('admins/'+id).set({...r,uid:me.id,name:me.name})}catch(e){say('#am','Couldn’t verify. Make sure you’ve been invited to this page as an editor.')}}
/* ---------- admin ---------- */
function buildAdmin(){
  const b=$('#aBody'),r=role();
  if(!r){b.dataset.on='';b.innerHTML=`<div class="panel auth"><div class="eyebrow">Herstyle team</div><h2>Admin login</h2><p style="color:var(--mute)">${me.id?`Signed in as <b>${esc(me.name)}</b>. Enter the email your super admin set up for you.`:'Log in, then enter the email your super admin set up for you.'}</p>${me.id?'<input id="ae" type="email" placeholder="you@email.com" style="margin-bottom:14px">':''}${window.HS_LOCAL&&!me.id?lform():''}<button class="btn" id="ag">${me.id?'Continue':'Log in'}</button><div id="am"></div><p class="sm"><a href="#" data-nav="login" style="color:var(--red)">Customer login</a></p></div>`;$('#ag').onclick=()=>me.id?claim():doLogin('#am');return}
  if(b.dataset.on==='1'){drawAdmin();return}b.dataset.on='1';
  const T=[['p','Products','products'],['o','Orders','orders'],['r','Revenue','revenue'],['t','Team'],['s','Settings']].filter(x=>x[2]?can(x[2]):r==='super');
  if(!T.some(x=>x[0]===tab))tab=T[0]?.[0]||'p';
  b.innerHTML=`<div class="title" style="padding-top:26px"><div class="eyebrow">${r==='super'?'Super admin':'Admin'}</div><h2>Hello, ${esc(me.name||'there')}</h2>${window.HS_LOCAL?'<p><a href="#" data-out class="sm" style="color:var(--red)">Log out</a></p>':''}</div>
  <div class="tabs">${T.map(x=>`<button class="chip" data-t="${x[0]}">${x[1]}</button>`).join('')}</div>
  <div data-p="p"><div class="panel" id="pf"><h3 id="fh">Add a new product</h3><label>Product name</label><input id="n" placeholder="e.g. Rose Silk Lace Front">
  <div class="row"><div><label>Price</label><input id="pr" placeholder="₦85,000"></div><div><label>Old price (optional, shown crossed out)</label><input id="wp" placeholder="₦100,000"></div></div>
  <div class="row"><div><label>Category</label><input id="ct" list="cl" placeholder="Lace Front"><datalist id="cl"><option>Lace Front</option><option>Bob</option><option>Curly</option><option>Straight</option><option>Braided</option><option>Human Hair</option></datalist></div><div><label>Badge</label><select id="bd"><option value="">None</option><option>New</option><option>Bestseller</option><option>Sale</option></select></div></div>
  <div class="row"><div><label>Length</label><input id="ln" placeholder="18 inches"></div><div><label>Colour</label><input id="cl2" placeholder="Burgundy"></div></div>
  <div class="row"><div><label>Texture</label><input id="tx" placeholder="Body wave"></div><div><label>Cap size</label><input id="cp" placeholder="Medium, adjustable"></div></div>
  <label>Detailed description</label><textarea id="ds" rows="4"></textarea><label class="ck"><input type="checkbox" id="pn"> Feature this wig at the top of the store</label>
  <label>Current photos and video (tap a photo to make it the cover, ✕ to remove)</label><div class="em" id="em"></div>
  <label>Add photos (one or more)</label><input id="im" type="file" accept="image/*" multiple><label>Add or replace video (optional)</label><input id="vd" type="file" accept="video/*">
  <p style="margin:16px 0 0"><button class="btn" id="save">Publish product</button> <button class="btn ghost sm hide" id="cancel">Cancel</button></p><div id="st"></div></div>
  <div class="panel"><h3>Listings (<span id="cnt"></span>)</h3><input id="lq" placeholder="Search listings…" style="margin-top:8px"><div id="ls"></div></div></div>
  <div data-p="o" class="panel"><h3>Orders</h3><div id="os"></div></div>
  <div data-p="r"><div class="panel"><div class="row"><div><label>View</label><select id="rm"><option value="m">Every month of the year</option><option value="y">Year by year</option></select></div><div id="ryw"><label>Year</label><select id="ry"></select></div></div><div class="sums" id="rs"></div></div><div class="panel"><h3 id="rh">Revenue</h3><div id="rb"></div><table class="tbl" id="rt"></table></div><div class="panel"><h3>Revenue by category</h3><div id="rp"></div></div><p class="sm">Counts confirmed, shipped and delivered orders. Change an order’s status in the Orders tab.</p></div>
  <div data-p="t" class="panel"><h3>Add an admin</h3><p class="sm">Enter their email and choose what they can access. They log in on the separate admin login page.</p><input id="te" type="email" placeholder="name@email.com"><div class="perm"><label><input type="checkbox" data-pk="products" checked> Products</label><label><input type="checkbox" data-pk="orders" checked> Orders</label><label><input type="checkbox" data-pk="revenue" checked> Revenue</label></div>
  <p style="margin:14px 0 0"><button class="btn sm" id="ta">Add admin</button> <button class="btn ghost sm" id="tc">Copy admin login link</button></p><div id="tm"></div><p class="sm">Emails can’t be sent from this page, so share the link yourself. Admins enter their email on the admin login page, and the first account to use it is linked to it (use Reset if it’s the wrong one). They must also be invited to this page on claude.ai as editors to see its data.</p><h3 style="margin-top:20px">Current admins</h3><div id="tl"></div></div>
  <div data-p="s" class="panel"><h3>Settings</h3><label>WhatsApp number for order help (with country code)</label><input id="wa"><p style="margin:14px 0 0"><button class="btn ghost sm" id="sw">Save</button></p><div id="sm"></div>${window.HS_LOCAL?'<h3 style="margin-top:22px">Backup</h3><p class="sm">Download everything (products, orders, admins) to move it to another computer.</p><button class="btn ghost sm" id="ex">Export</button> <label class="btn ghost sm" style="display:inline-block;margin:0">Import<input type="file" id="imp" accept=".json" hidden></label>':''}</div>`;
  b.onclick=async e=>{const d=e.target.dataset;try{
    if(d.t){tab=d.t;drawAdmin()}
    if(d.ed)startEdit(d.ed);
    if(d.ri!==undefined){const i=+d.ri;gone.push(emImgs[i]);emImgs.splice(i,1);drawMedia()}
    if(d.rv!==undefined){gone.push(emVid);emVid='';drawMedia()}
    if(d.mc!==undefined){emImgs.unshift(...emImgs.splice(+d.mc,1));drawMedia()}
    if(d.s){await db.doc('products/'+d.s).update({soldOut:!find(d.s).soldOut})}
    if(d.d&&confirm('Delete this product?')){const p=find(d.d);await db.doc('products/'+d.d).delete();if(assets)for(const u of[...(p.images||[]),p.video].filter(Boolean)){const i=u.split('/_blob/')[1];if(i)try{await assets.delete(i)}catch(_){}}}
    if(d.x&&confirm('Remove this admin?'))await db.doc('admins/'+d.x).delete();
    if(d.rs){const{id,...r}=admins.find(x=>x.id===d.rs);await db.doc('admins/'+d.rs).set({...r,uid:null,name:''})}
  }catch(err){alert('Action failed: '+(err.message||err.code))}};
  b.onchange=async e=>{const t=e.target,d=t.dataset;try{
    if(d.pe)await db.doc('products/'+d.pe).update({price:t.value.trim()});
    if(d.o){const[u,i]=d.o.split('|'),ref=db.doc('orders/'+u),l=((await ref.get()).data()||{}).list||[];l.forEach(o=>{if(o.id===i)o.status=t.value});await ref.set({list:l})}
    if(d.ep){const[k,p]=d.ep.split('|'),a=admins.find(x=>x.id===k);const{id,...rest}=a;await db.doc('admins/'+k).set({...rest,perms:{...a.perms,[p]:t.checked}})}
  }catch(x){alert('Could not save that change')}};
  $('#save').onclick=saveProduct;$('#cancel').onclick=resetForm;$('#lq').oninput=drawAdmin;drawMedia();
  if(window.HS_LOCAL){$('#ex').onclick=async()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(await user.dump())],{type:'application/json'}));a.download='herstyle-backup.json';a.click()};$('#imp').onchange=async e=>{try{await user.load(JSON.parse(await e.target.files[0].text()));say('#sm','Imported ✓')}catch(x){say('#sm','That file couldn’t be imported')}}}
  $('#wa').value=settings.whatsapp||'';$('#rm').onchange=$('#ry').onchange=drawRev;
  $('#sw').onclick=async()=>{try{await db.doc('settings/site').set({whatsapp:$('#wa').value.trim()});say('#sm','Saved ✓')}catch(e){say('#sm','Could not save')}};
  $('#tc').onclick=()=>{const u=(window.HS_LOCAL?location.href.split('#')[0]:LINK)+'#admin-login';try{navigator.clipboard.writeText(u).then(()=>say('#tm','Link copied ✓'),()=>say('#tm',esc(u)))}catch(_){say('#tm',esc(u))}};
  $('#ta').onclick=async()=>{const em=$('#te').value.trim().toLowerCase();if(!/^\S+@\S+\.\S+$/.test(em))return say('#tm','Please enter a valid email.');const perms={};$$('[data-pk]').forEach(c=>perms[c.dataset.pk]=c.checked);
    try{await db.doc('admins/'+key(em)).set({email:em,perms,at:Date.now(),uid:null,name:''});$('#te').value='';say('#tm','Admin added ✓')}catch(e){say('#tm','Could not add admin')}};
  drawAdmin()}
function drawAdmin(){
  if(!$('#ls'))return;$$('[data-p]').forEach(p=>p.classList.toggle('hide',p.dataset.p!==tab));$$('.tabs .chip').forEach(c=>c.classList.toggle('on',c.dataset.t===tab));
  $('#cnt').textContent=products.length;
  const q=($('#lq').value||'').toLowerCase();$('#ls').innerHTML=products.filter(p=>(p.name+' '+(p.category||'')).toLowerCase().includes(q)).map(p=>`<div class="li">${cover(p)?`<img src="${esc(cover(p))}" alt="">`:'<span class="z"></span>'}<div><b>${esc(p.name)}</b><small>${esc(p.category||'')}${p.soldOut?' · sold out':''}${p.pinned?' · featured':''}</small></div><input class="pi" data-pe="${esc(p.id)}" value="${esc(p.price)}" aria-label="Price"><button class="btn ghost sm" data-ed="${esc(p.id)}">Edit</button><button class="btn ghost sm" data-s="${esc(p.id)}">${p.soldOut?'Available':'Sold out'}</button><button class="btn ghost sm" data-d="${esc(p.id)}">Delete</button></div>`).join('')||'<p class="sm">No products yet.</p>';
  $('#os').innerHTML=orders.map(o=>`<div class="li" style="align-items:flex-start"><div style="white-space:normal"><b style="white-space:normal">#${esc(o.id.slice(0,6).toUpperCase())} · ${esc(o.name)} · ${esc(o.currency)}${(o.total||0).toLocaleString()}</b><small>${esc(o.phone)} · ${esc(o.address)}<br>${(o.items||[]).map(i=>i.qty+'× '+esc(i.name)).join(', ')}${o.note?'<br>Note: '+esc(o.note):''} · ${esc(o.pay)}</small></div><select data-o="${esc(o.uid)}|${esc(o.id)}" style="width:auto">${['new','confirmed','shipped','delivered','cancelled'].map(s=>`<option ${o.status===s?'selected':''}>${s}</option>`).join('')}</select></div>`).join('')||'<p class="sm">No orders yet.</p>';
  $('#tl').innerHTML=admins.map(a=>`<div class="li" style="flex-wrap:wrap"><div><b>${esc(a.email)}</b><small>${a.uid?'Linked to '+esc(a.name||'an account'):'Not signed in yet'}</small></div>${['products','orders','revenue'].map(k=>`<label style="display:inline-flex;gap:5px;align-items:center;margin:0"><input type="checkbox" data-ep="${esc(a.id)}|${k}" ${a.perms?.[k]?'checked':''}> ${k}</label>`).join('')}${a.uid?`<button class="btn ghost sm" data-rs="${esc(a.id)}">Reset</button>`:''}<button class="btn ghost sm" data-x="${esc(a.id)}">Remove</button></div>`).join('')||'<p class="sm">No admins added yet.</p>';
  drawRev()}

/* ---------- revenue charts ---------- */
const sh=v=>v>=1e6?(v/1e6).toFixed(1)+'M':v>=1e3?Math.round(v/1e3)+'k':Math.round(v);
function bars(d){const W=640,H=310,m=20,base=H-85,mx=Math.max(1,...d.map(x=>x.v)),bw=(W-m*2)/d.length;
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%"><defs><linearGradient id="bgr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff6f9c"/><stop offset="1" stop-color="#c8102e"/></linearGradient></defs>`+d.map((x,i)=>{const h=(base-30)*x.v/mx,X=m+i*bw+bw*.15,cx=X+bw*.35,long=x.l.length>4;return `<rect x="${X}" y="${base-h}" width="${bw*.7}" height="${Math.max(h,2)}" rx="6" fill="url(#bgr)"><title>${esc(x.l)}: ${x.v.toLocaleString()}</title></rect><text x="${cx}" y="${base+16}" ${long?`transform="rotate(-40 ${cx} ${base+16})" text-anchor="end"`:'text-anchor="middle"'} font-size="12" font-weight="${x.c?700:400}" fill="${x.c?'#c8102e':'currentColor'}">${esc(x.l)}</text>${x.v?`<text x="${cx}" y="${base-h-6}" text-anchor="middle" font-size="11" fill="currentColor">${sh(x.v)}</text>`:''}`}).join('')+'</svg>'}
function pie(d){const t=d.reduce((a,x)=>a+x.v,0);if(!t)return'<p class="sm" style="text-align:center">No revenue yet for this period.</p>';
  const C=['#c8102e','#ff6f9c','#e8466f','#ffb3c8','#8f0a22','#f7869f','#b5213b'],P=(a,r)=>[110+r*Math.cos(a),110+r*Math.sin(a)];let a0=-Math.PI/2;
  const s=d.map((x,i)=>{const a1=a0+2*Math.PI*x.v/t,[x0,y0]=P(a0,100),[x1,y1]=P(a1,100),p=d.length===1?`<circle cx="110" cy="110" r="100" fill="${C[0]}"/>`:`<path d="M110 110L${x0} ${y0}A100 100 0 ${a1-a0>Math.PI?1:0} 1 ${x1} ${y1}Z" fill="${C[i%7]}"><title>${esc(x.l)}</title></path>`;a0=a1;return p}).join('');
  return `<svg viewBox="0 0 220 220" style="width:min(260px,100%);display:block;margin:auto">${s}<circle cx="110" cy="110" r="52" style="fill:var(--card)"/></svg><div class="leg">${d.map((x,i)=>`<span><i style="background:${C[i%7]}"></i>${esc(x.l)} · ${Math.round(x.v/t*100)}%</span>`).join('')}</div>`}
function drawRev(){if(!$('#rb'))return;
  const ok=orders.filter(o=>!['new','cancelled'].includes(o.status)),Y=o=>new Date(o.createdAt).getFullYear(),sy=$('#ry'),keep=sy.value;
  const yrs=[...new Set([new Date().getFullYear(),...ok.map(Y)])].sort((a,b)=>b-a);
  if(sy.options.length!==yrs.length)sy.innerHTML=yrs.map(y=>`<option>${y}</option>`).join('');sy.value=keep&&yrs.includes(+keep)?keep:new Date().getFullYear();
  const m=$('#rm').value==='m',yr=+sy.value,cur=(ok[0]||{}).currency||'₦',f=n=>cur+Math.round(n).toLocaleString();$('#ryw').classList.toggle('hide',!m);
  let d,sel;if(m){sel=ok.filter(o=>Y(o)===yr);d=MO.map((l,i)=>({l,v:0,n:0,c:yr===new Date().getFullYear()&&i===new Date().getMonth()}));sel.forEach(o=>{const x=d[new Date(o.createdAt).getMonth()];x.v+=o.total||0;x.n++})}
  else{sel=ok;d=[...yrs].reverse().map(y=>{const q=ok.filter(o=>Y(o)===y);return{l:''+y,v:q.reduce((a,o)=>a+(o.total||0),0),n:q.length,c:y===new Date().getFullYear()}})}
  const tot=sel.reduce((a,o)=>a+(o.total||0),0);
  $('#rs').innerHTML=`<div><b>${f(tot)}</b>Revenue</div><div><b>${sel.length}</b>Orders</div><div><b>${f(sel.length?tot/sel.length:0)}</b>Avg. order</div>`;$('#rb').innerHTML=bars(d);$('#rh').textContent=m?`${yr} revenue: January to December`:'Revenue by year';$('#rt').innerHTML=d.map(x=>`<tr style="${x.c?'font-weight:600':''}"><td>${x.l}${x.c?' · now':''}</td><td>${x.n} order${x.n==1?'':'s'}</td><td>${f(x.v)}</td></tr>`).join('');
  const c={};sel.forEach(o=>(o.items||[]).forEach(i=>{const k=i.cat||'Other';c[k]=(c[k]||0)+num(i)*i.qty}));$('#rp').innerHTML=pie(Object.entries(c).map(([l,v])=>({l,v})).sort((a,b)=>b.v-a.v))}

let editId=null,emImgs=[],emVid='',gone=[];
function drawMedia(){const e=$('#em');if(!e)return;e.innerHTML=emImgs.map((u,i)=>`<span class="mt" title="Tap to make cover"><img src="${esc(u)}" data-mc="${i}" alt="">${i?'':'<i>Cover</i>'}<button data-ri="${i}" aria-label="Remove photo">✕</button></span>`).join('')+(emVid?'<span class="mt vid">🎬 Video<button data-rv aria-label="Remove video">✕</button></span>':'')||'<p class="sm" style="margin:0">No media yet.</p>'}
function resetForm(){editId=null;emImgs=[];emVid='';gone=[];['n','pr','wp','ct','ln','cl2','tx','cp','ds','im','vd'].forEach(i=>$('#'+i).value='');$('#bd').value='';$('#pn').checked=false;$('#fh').textContent='Add a new product';$('#save').textContent='Publish product';$('#cancel').classList.add('hide');drawMedia()}
function startEdit(id){const p=find(id);if(!p||p.demo)return;resetForm();editId=id;const v={n:p.name,pr:p.price,wp:p.was,ct:p.category,ln:p.length,cl2:p.colour,tx:p.texture,cp:p.cap,ds:p.description};for(const k in v)$('#'+k).value=v[k]||'';
  $('#bd').value=p.badge||'';$('#pn').checked=!!p.pinned;emImgs=[...(p.images||[])];emVid=p.video||'';$('#fh').textContent='Edit product';$('#save').textContent='Save changes';$('#cancel').classList.remove('hide');drawMedia();tab='p';drawAdmin();$('#pf').scrollIntoView({behavior:'smooth'})}
async function saveProduct(){
  const name=$('#n').value.trim();if(!name)return say('#st','Please enter a product name.');
  const btn=$('#save');btn.disabled=true;
  try{const im=[...emImgs],fs=[...$('#im').files];for(let i=0;i<fs.length;i++){say('#st',`Uploading photo ${i+1} of ${fs.length}…`);im.push((await assets.upload(fs[i])).url)}
    let video=emVid;if($('#vd').files[0]){if(emVid)gone.push(emVid);say('#st','Uploading video…');video=(await assets.upload($('#vd').files[0])).url}
    const data={name,price:$('#pr').value.trim(),was:$('#wp').value.trim(),badge:$('#bd').value,pinned:$('#pn').checked,category:$('#ct').value.trim(),length:$('#ln').value.trim(),colour:$('#cl2').value.trim(),texture:$('#tx').value.trim(),cap:$('#cp').value.trim(),description:$('#ds').value.trim(),images:im,video};
    if(editId)await db.doc('products/'+editId).update(data);else await db.collection('products').add({...data,soldOut:false,createdAt:Date.now()});
    for(const u of gone){const i=(u||'').split('/_blob/')[1];if(i&&assets)try{await assets.delete(i)}catch(_){}}
    const was=editId;resetForm();say('#st',was?'Changes saved ✓':'Published! It’s live on the store ✓')}
  catch(e){say('#st','Something went wrong: '+(e.message||e.code||'try again'))}btn.disabled=false}

const lform=()=>'<input id="ln2" placeholder="Your name" style="margin-bottom:10px"><input id="le" type="email" placeholder="Email" style="margin-bottom:14px">';
async function doLogin(sel){if(window.HS_LOCAL){const n=$('#ln2')?.value.trim(),em=$('#le')?.value.trim();if(!n||!/\S+@\S+\.\S+/.test(em||''))return say(sel,'Please enter your name and email.');user.signIn(n,em)}
  await refreshMe();if(!me.id)say(sel,'We couldn’t find a signed-in account. Open this page while signed in to claude.ai, then try again.')}
const refresh=()=>{renderStore();if(view==='cart')drawCart();if(view==='admin')buildAdmin();if(view==='login'&&me.id&&role())nav('admin')};
(async()=>{
  $$('.title,.perks .grid>div').forEach(e=>e.classList.add('rv'));saveCart();renderStore();
  if(window.HS_LOCAL)document.body.insertAdjacentHTML('afterbegin','<div class="sm" style="text-align:center;padding:6px;background:var(--blush)">Running locally: your data is saved in this browser only.</div>');
  const cl=window.claude;
  if(cl){try{user=await cl.use('user');if(user){me={email:'',...(await user.me())}}}catch(e){}
    try{assets=await cl.use('assets')}catch(e){}try{db=await cl.use('db')}catch(e){}
    if(db){const on=(q,f)=>q.onSnapshot(s=>{f(s);refresh()},()=>{});
      on(db.collection('products').orderBy('createdAt','desc'),s=>products=s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>!!b.pinned-!!a.pinned));
      on(db.doc('settings/site'),s=>settings=s.data()||{});
      on(db.collection('orders'),s=>orders=s.docs.flatMap(d=>(d.data().list||[]).map(o=>({...o,uid:d.id}))).sort((a,b)=>b.createdAt-a.createdAt));
      on(db.collection('admins'),s=>admins=s.docs.map(d=>({id:d.id,...d.data()})))}}
  const h=location.hash.slice(1);h==='admin-login'?nav('admin'):h==='login'?nav('login'):refresh()})();
